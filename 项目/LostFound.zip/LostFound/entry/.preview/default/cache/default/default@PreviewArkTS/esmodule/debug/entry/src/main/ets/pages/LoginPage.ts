if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    context?: common.UIAbilityContext;
    account?: string;
    pwd?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import dataPreferences from "@ohos:data.preferences";
import type common from "@ohos:app.ability.common";
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.context = getContext(this) as common.UIAbilityContext;
        this.__account = new ObservedPropertySimplePU('', this, "account");
        this.__pwd = new ObservedPropertySimplePU('', this, "pwd");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.account !== undefined) {
            this.account = params.account;
        }
        if (params.pwd !== undefined) {
            this.pwd = params.pwd;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__account.purgeDependencyOnElmtId(rmElmtId);
        this.__pwd.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__account.aboutToBeDeleted();
        this.__pwd.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private context: common.UIAbilityContext;
    private __account: ObservedPropertySimplePU<string>;
    get account() {
        return this.__account.get();
    }
    set account(newValue: string) {
        this.__account.set(newValue);
    }
    private __pwd: ObservedPropertySimplePU<string>;
    get pwd() {
        return this.__pwd.get();
    }
    set pwd(newValue: string) {
        this.__pwd.set(newValue);
    }
    async login() {
        if (!this.account || !this.pwd) {
            promptAction.showToast({ message: '请输入账号和密码', duration: 1000 });
            return;
        }
        const pref = await dataPreferences.getPreferences(this.context, 'auth');
        const localAcc = await pref.get('account', '') as string;
        const localPwd = await pref.get('pwd', '') as string;
        if (this.account !== localAcc || this.pwd !== localPwd) {
            promptAction.showToast({ message: '账号或密码错误', duration: 1500 });
            return;
        }
        // 成功
        router.replaceUrl({ url: 'pages/Index' });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/LoginPage.ets(29:5)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.lostfound", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/LoginPage.ets(30:7)", "entry");
            Image.width('100%');
            Image.height('100%');
            Image.objectFit(ImageFit.Cover);
            Image.blur(20);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(31:7)", "entry");
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('失物招领登录');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(32:9)", "entry");
            Text.fontSize(28);
            Text.fontColor('#FFF');
            Text.margin({ bottom: 40 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(33:9)", "entry");
            Column.padding(20);
            Column.width('80%');
            Column.backgroundColor('#20FFFFFF');
            Column.borderRadius(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '账号', text: this.account });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(34:11)", "entry");
            TextInput.onChange(v => this.account = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '密码', text: this.pwd });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(36:11)", "entry");
            TextInput.type(InputType.Password);
            TextInput.margin({ top: 12 });
            TextInput.onChange(v => this.pwd = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('登录');
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(39:11)", "entry");
            Button.width('100%');
            Button.margin({ top: 24 });
            Button.onClick(() => this.login());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(40:11)", "entry");
            Row.margin({ top: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('还没账号？');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(41:13)", "entry");
            Text.fontColor('#FFF');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('立即注册');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(42:13)", "entry");
            Text.fontColor('#FFD700');
            Text.onClick(() => router.pushUrl({ url: 'pages/RegisterPage' }));
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.example.lostfound", moduleName: "entry", pagePath: "pages/LoginPage", pageFullPath: "entry/src/main/ets/pages/LoginPage", integratedHsp: "false", moduleType: "followWithHap" });
