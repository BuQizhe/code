if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RegisterPage_Params {
    context?: common.UIAbilityContext;
    account?: string;
    pwd?: string;
    pwd2?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import dataPreferences from "@ohos:data.preferences";
import type common from "@ohos:app.ability.common";
class RegisterPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.context = getContext(this) as common.UIAbilityContext;
        this.__account = new ObservedPropertySimplePU('', this, "account");
        this.__pwd = new ObservedPropertySimplePU('', this, "pwd");
        this.__pwd2 = new ObservedPropertySimplePU('', this, "pwd2");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RegisterPage_Params) {
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.account !== undefined) {
            this.account = params.account;
        }
        if (params.pwd !== undefined) {
            this.pwd = params.pwd;
        }
        if (params.pwd2 !== undefined) {
            this.pwd2 = params.pwd2;
        }
    }
    updateStateVars(params: RegisterPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__account.purgeDependencyOnElmtId(rmElmtId);
        this.__pwd.purgeDependencyOnElmtId(rmElmtId);
        this.__pwd2.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__account.aboutToBeDeleted();
        this.__pwd.aboutToBeDeleted();
        this.__pwd2.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private context: common.UIAbilityContext;
    private __account: ObservedPropertySimplePU<string>;
    get account() {
        return this.__account.get();
    }
    set account(newValue: string) {
        this.__account.set(newValue);
    }
    private __pwd: ObservedPropertySimplePU<string>;
    get pwd() {
        return this.__pwd.get();
    }
    set pwd(newValue: string) {
        this.__pwd.set(newValue);
    }
    private __pwd2: ObservedPropertySimplePU<string>;
    get pwd2() {
        return this.__pwd2.get();
    }
    set pwd2(newValue: string) {
        this.__pwd2.set(newValue);
    }
    async register() {
        if (!this.account || !this.pwd || !this.pwd2) {
            promptAction.showToast({ message: '请填完整', duration: 1000 });
            return;
        }
        if (this.pwd !== this.pwd2) {
            promptAction.showToast({ message: '两次密码不一致', duration: 1500 });
            return;
        }
        const pref = await dataPreferences.getPreferences(this.context, 'auth');
        await pref.put('account', this.account);
        await pref.put('pwd', this.pwd); // 正式请哈希
        await pref.flush();
        promptAction.showToast({ message: '注册成功！', duration: 1500 });
        router.replaceUrl({ url: 'pages/Index' }); // 直接进首页
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(31:5)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.lostfound", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/RegisterPage.ets(32:7)", "entry");
            Image.width('100%');
            Image.height('100%');
            Image.objectFit(ImageFit.Cover);
            Image.blur(20);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(33:7)", "entry");
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('注册账号');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(34:9)", "entry");
            Text.fontSize(28);
            Text.fontColor('#FFF');
            Text.margin({ bottom: 40 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(35:9)", "entry");
            Column.padding(20);
            Column.width('80%');
            Column.backgroundColor('#20FFFFFF');
            Column.borderRadius(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '账号', text: this.account });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(36:11)", "entry");
            TextInput.onChange(v => this.account = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '密码', text: this.pwd });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(38:11)", "entry");
            TextInput.type(InputType.Password);
            TextInput.margin({ top: 12 });
            TextInput.onChange(v => this.pwd = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '再次输入密码', text: this.pwd2 });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(41:11)", "entry");
            TextInput.type(InputType.Password);
            TextInput.margin({ top: 12 });
            TextInput.onChange(v => this.pwd2 = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('注册并登录');
            Button.debugLine("entry/src/main/ets/pages/RegisterPage.ets(44:11)", "entry");
            Button.width('100%');
            Button.margin({ top: 24 });
            Button.onClick(() => this.register());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RegisterPage.ets(45:11)", "entry");
            Row.margin({ top: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('已有账号？');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(46:13)", "entry");
            Text.fontColor('#FFF');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('立即登录');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(47:13)", "entry");
            Text.fontColor('#FFD700');
            Text.onClick(() => router.back());
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "RegisterPage";
    }
}
registerNamedRoute(() => new RegisterPage(undefined, {}), "", { bundleName: "com.example.lostfound", moduleName: "entry", pagePath: "pages/RegisterPage", pageFullPath: "entry/src/main/ets/pages/RegisterPage", integratedHsp: "false", moduleType: "followWithHap" });
