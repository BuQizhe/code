if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    list?: LostItem[];
    isRefreshing?: boolean;
    userName?: string;
    avatarUri?: string;
    context?: common.UIAbilityContext;
    pref?: dataPreferences.Preferences | null;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import dataPreferences from "@ohos:data.preferences";
import picker from "@ohos:file.picker";
import type common from "@ohos:app.ability.common";
interface LostItem {
    id: string;
    title: string;
    desc: string;
    phone: string;
    time: string;
    detail?: string;
    comments?: string[];
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__list = new ObservedPropertyObjectPU([], this, "list");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.__userName = new ObservedPropertySimplePU('', this, "userName");
        this.__avatarUri = new ObservedPropertySimplePU('', this, "avatarUri");
        this.context = getContext(this) as common.UIAbilityContext;
        this.pref = null;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.list !== undefined) {
            this.list = params.list;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.userName !== undefined) {
            this.userName = params.userName;
        }
        if (params.avatarUri !== undefined) {
            this.avatarUri = params.avatarUri;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.pref !== undefined) {
            this.pref = params.pref;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__list.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
        this.__userName.purgeDependencyOnElmtId(rmElmtId);
        this.__avatarUri.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__list.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        this.__userName.aboutToBeDeleted();
        this.__avatarUri.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __list: ObservedPropertyObjectPU<LostItem[]>;
    get list() {
        return this.__list.get();
    }
    set list(newValue: LostItem[]) {
        this.__list.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    private __userName: ObservedPropertySimplePU<string>;
    get userName() {
        return this.__userName.get();
    }
    set userName(newValue: string) {
        this.__userName.set(newValue);
    }
    private __avatarUri: ObservedPropertySimplePU<string>;
    get avatarUri() {
        return this.__avatarUri.get();
    }
    set avatarUri(newValue: string) {
        this.__avatarUri.set(newValue);
    }
    private context: common.UIAbilityContext;
    private pref: dataPreferences.Preferences | null;
    async aboutToAppear() {
        this.pref = await dataPreferences.getPreferences(this.context, 'lost');
        const authPref = await dataPreferences.getPreferences(this.context, 'auth');
        this.userName = await authPref.get('account', '同学') as string;
        this.avatarUri = await authPref.get('avatar', '') as string;
        await this.loadData();
    }
    private async loadData() {
        if (!this.pref)
            return;
        const raw = await this.pref.get('data', '[]') as string;
        this.list = JSON.parse(raw);
    }
    async save() {
        if (!this.pref)
            return;
        await this.pref.put('data', JSON.stringify(this.list));
        await this.pref.flush();
        promptAction.showToast({ message: '保存成功', duration: 1500 });
    }
    // 换头像：图库选择
    async pickAvatar() {
        try {
            const photoPicker = new picker.PhotoViewPicker();
            const res = await photoPicker.select({
                MIMEType: picker.PhotoViewMIMETypes.IMAGE_TYPE,
                maxSelectNumber: 1
            });
            if (res.photoUris && res.photoUris.length > 0) {
                this.avatarUri = res.photoUris[0];
                const authPref = await dataPreferences.getPreferences(this.context, 'auth');
                await authPref.put('avatar', this.avatarUri);
                await authPref.flush();
                promptAction.showToast({ message: '头像已更新' });
            }
        }
        catch (e) {
            promptAction.showToast({ message: '取消选择' });
        }
    }
    onBackPress(): boolean {
        router.replaceUrl({ url: 'pages/LoginPage' });
        return true;
    }
    itemCard(item: LostItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(77:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.shadow({ radius: 4, color: '#20000000' });
            Row.onClick(() => {
                router.pushUrl({ url: 'pages/DetailPage', params: { item: JSON.stringify(item) } });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(78:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(79:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.desc);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(80:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.maxLines(2);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`联系电话：${item.phone}  时间：${item.time}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(81:9)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777226, "type": 20000, params: [], "bundleName": "com.example.lostfound", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(85:7)", "entry");
            Image.width(24);
            Image.height(24);
            Image.onClick(async () => {
                this.list = this.list.filter(i => i.id !== item.id);
                await this.save();
            });
        }, Image);
        Row.pop();
    }
    emptyUI(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(104:5)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(105:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.lostfound", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(106:7)", "entry");
            Image.width(120);
            Image.height(120);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('暂无失物，快去发布第一条吧~');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(107:7)", "entry");
            Text.fontSize(14);
            Text.fontColor('#999');
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(112:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部背景+头像+返回
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(114:7)", "entry");
            // 顶部背景+头像+返回
            Stack.height(200);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.lostfound", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(115:9)", "entry");
            Image.width('100%');
            Image.height(200);
            Image.objectFit(ImageFit.Cover);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(116:9)", "entry");
            Row.alignItems(VerticalAlign.Center);
            Row.margin({ top: 80, left: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.avatarUri ? this.avatarUri : { "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.lostfound", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(117:11)", "entry");
            Image.width(60);
            Image.height(60);
            Image.borderRadius(30);
            Image.onClick(() => this.pickAvatar());
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(119:11)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`欢迎，${this.userName}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(120:13)", "entry");
            Text.fontSize(18);
            Text.fontColor('#FFF');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('点头像可更换');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(121:13)", "entry");
            Text.fontSize(12);
            Text.fontColor('#FFF');
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('< 返回');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(125:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFF');
            Text.position({ x: 20, y: 40 });
            Text.onClick(() => {
                router.replaceUrl({ url: 'pages/LoginPage' });
            });
        }, Text);
        Text.pop();
        // 顶部背景+头像+返回
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // ✅ Refresh 事件挂在组件上，构造参数里不写 onRefreshing
            Refresh.create({ refreshing: this.isRefreshing });
            Refresh.debugLine("entry/src/main/ets/pages/Index.ets(132:7)", "entry");
            // ✅ Refresh 事件挂在组件上，构造参数里不写 onRefreshing
            Refresh.onRefreshing(async () => {
                this.isRefreshing = true;
                await this.loadData();
                this.isRefreshing = false;
                promptAction.showToast({ message: '已刷新' });
            });
            // ✅ Refresh 事件挂在组件上，构造参数里不写 onRefreshing
            Refresh.layoutWeight(1);
            // ✅ Refresh 事件挂在组件上，构造参数里不写 onRefreshing
            Refresh.backgroundColor('#F5F5F5');
        }, Refresh);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(133:9)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.list.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.emptyUI.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/Index.ets(137:13)", "entry");
                        List.padding({ left: 16, right: 16 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/Index.ets(139:17)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.itemCard.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.list, forEachItemGenFunction, (item: LostItem) => item.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        // ✅ Refresh 事件挂在组件上，构造参数里不写 onRefreshing
        Refresh.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 悬浮发布
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(155:7)", "entry");
            // 悬浮发布
            Row.width(56);
            // 悬浮发布
            Row.height(56);
            // 悬浮发布
            Row.backgroundColor('#007DFF');
            // 悬浮发布
            Row.borderRadius(28);
            // 悬浮发布
            Row.position({ x: '80%', y: '85%' });
            // 悬浮发布
            Row.shadow({ radius: 6, color: '#40000000' });
            // 悬浮发布
            Row.onClick(() => router.pushUrl({ url: 'pages/AddPage' }));
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777227, "type": 20000, params: [], "bundleName": "com.example.lostfound", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(156:9)", "entry");
            Image.width(32);
            Image.height(32);
            Image.fillColor('#FFF');
        }, Image);
        // 悬浮发布
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.lostfound", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
