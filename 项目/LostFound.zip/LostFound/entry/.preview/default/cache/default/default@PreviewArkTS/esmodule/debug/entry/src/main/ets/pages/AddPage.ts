if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AddPage_Params {
    context?: common.UIAbilityContext;
    title?: string;
    desc?: string;
    phone?: string;
    detail?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import dataPreferences from "@ohos:data.preferences";
import type common from "@ohos:app.ability.common";
interface LostItem {
    id: string;
    title: string;
    desc: string;
    phone: string;
    time: string;
    detail?: string;
    comments?: string[];
}
class AddPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.context = getContext(this) as common.UIAbilityContext;
        this.__title = new ObservedPropertySimplePU('', this, "title");
        this.__desc = new ObservedPropertySimplePU('', this, "desc");
        this.__phone = new ObservedPropertySimplePU('', this, "phone");
        this.__detail = new ObservedPropertySimplePU('' // 详细信息
        , this, "detail");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AddPage_Params) {
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.desc !== undefined) {
            this.desc = params.desc;
        }
        if (params.phone !== undefined) {
            this.phone = params.phone;
        }
        if (params.detail !== undefined) {
            this.detail = params.detail;
        }
    }
    updateStateVars(params: AddPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__title.purgeDependencyOnElmtId(rmElmtId);
        this.__desc.purgeDependencyOnElmtId(rmElmtId);
        this.__phone.purgeDependencyOnElmtId(rmElmtId);
        this.__detail.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__title.aboutToBeDeleted();
        this.__desc.aboutToBeDeleted();
        this.__phone.aboutToBeDeleted();
        this.__detail.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private context: common.UIAbilityContext;
    private __title: ObservedPropertySimplePU<string>;
    get title() {
        return this.__title.get();
    }
    set title(newValue: string) {
        this.__title.set(newValue);
    }
    private __desc: ObservedPropertySimplePU<string>;
    get desc() {
        return this.__desc.get();
    }
    set desc(newValue: string) {
        this.__desc.set(newValue);
    }
    private __phone: ObservedPropertySimplePU<string>;
    get phone() {
        return this.__phone.get();
    }
    set phone(newValue: string) {
        this.__phone.set(newValue);
    }
    private __detail: ObservedPropertySimplePU<string>; // 详细信息
    get detail() {
        return this.__detail.get();
    }
    set detail(newValue: string) {
        this.__detail.set(newValue);
    }
    async save() {
        if (!this.title || !this.phone) {
            promptAction.showToast({ message: '请填写物品名称和电话', duration: 1000 });
            return;
        }
        const pref = await dataPreferences.getPreferences(this.context, 'lost');
        const raw = await pref.get('data', '[]') as string;
        const old: LostItem[] = JSON.parse(raw);
        old.push({
            id: Date.now().toString(),
            title: this.title,
            desc: this.desc,
            phone: this.phone,
            detail: this.detail,
            time: new Date().toLocaleString(),
            comments: []
        });
        await pref.put('data', JSON.stringify(old));
        await pref.flush();
        promptAction.showToast({ message: '发布成功！', duration: 1500 });
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddPage.ets(49:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
            Column.padding(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddPage.ets(50:7)", "entry");
            Row.width('100%');
            Row.padding(16);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('新增失物');
            Text.debugLine("entry/src/main/ets/pages/AddPage.ets(51:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddPage.ets(52:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('保存');
            Text.debugLine("entry/src/main/ets/pages/AddPage.ets(53:9)", "entry");
            Text.fontSize(18);
            Text.fontColor('#007DFF');
            Text.onClick(() => this.save());
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/AddPage.ets(56:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.padding({ top: 12 });
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddPage.ets(57:9)", "entry");
            Column.padding(16);
            Column.width('100%');
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(12);
            Column.shadow({ radius: 4, color: '#20000000' });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('物品名称');
            Text.debugLine("entry/src/main/ets/pages/AddPage.ets(58:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '如：黑色钱包', text: this.title });
            TextInput.debugLine("entry/src/main/ets/pages/AddPage.ets(59:11)", "entry");
            TextInput.onChange(v => this.title = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('描述信息');
            Text.debugLine("entry/src/main/ets/pages/AddPage.ets(62:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '丢失地点、特征等', text: this.desc });
            TextInput.debugLine("entry/src/main/ets/pages/AddPage.ets(63:11)", "entry");
            TextInput.onChange(v => this.desc = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('联系电话');
            Text.debugLine("entry/src/main/ets/pages/AddPage.ets(66:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '手机号', text: this.phone });
            TextInput.debugLine("entry/src/main/ets/pages/AddPage.ets(67:11)", "entry");
            TextInput.type(InputType.PhoneNumber);
            TextInput.onChange(v => this.phone = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('详细信息');
            Text.debugLine("entry/src/main/ets/pages/AddPage.ets(71:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '详细描述、照片文字等（可选）', text: this.detail });
            TextArea.debugLine("entry/src/main/ets/pages/AddPage.ets(72:11)", "entry");
            TextArea.height(120);
            TextArea.onChange(v => this.detail = v);
        }, TextArea);
        Column.pop();
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('发布失物');
            Button.debugLine("entry/src/main/ets/pages/AddPage.ets(78:7)", "entry");
            Button.width('90%');
            Button.margin({ bottom: 20 });
            Button.onClick(() => this.save());
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "AddPage";
    }
}
registerNamedRoute(() => new AddPage(undefined, {}), "", { bundleName: "com.example.lostfound", moduleName: "entry", pagePath: "pages/AddPage", pageFullPath: "entry/src/main/ets/pages/AddPage", integratedHsp: "false", moduleType: "followWithHap" });
