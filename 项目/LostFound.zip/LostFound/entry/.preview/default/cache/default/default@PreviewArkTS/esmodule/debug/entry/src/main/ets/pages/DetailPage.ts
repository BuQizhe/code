if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DetailPage_Params {
    context?: common.UIAbilityContext;
    item?: LostItem;
    comment?: string;
    comments?: string[];
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import dataPreferences from "@ohos:data.preferences";
import type common from "@ohos:app.ability.common";
interface LostItem {
    id: string;
    title: string;
    desc: string;
    phone: string;
    time: string;
    detail?: string;
    comments?: string[];
}
class DetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.context = getContext(this) as common.UIAbilityContext;
        this.__item = new ObservedPropertyObjectPU(JSON.parse((router.getParams() as Record<string, string>)?.item ?? '{}') as LostItem, this, "item");
        this.__comment = new ObservedPropertySimplePU('', this, "comment");
        this.__comments = new ObservedPropertyObjectPU(this.item.comments ?? []
        // 提交评论
        , this, "comments");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DetailPage_Params) {
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.comment !== undefined) {
            this.comment = params.comment;
        }
        if (params.comments !== undefined) {
            this.comments = params.comments;
        }
    }
    updateStateVars(params: DetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__item.purgeDependencyOnElmtId(rmElmtId);
        this.__comment.purgeDependencyOnElmtId(rmElmtId);
        this.__comments.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__item.aboutToBeDeleted();
        this.__comment.aboutToBeDeleted();
        this.__comments.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private context: common.UIAbilityContext;
    // 1. 用点语法取参数，避免 [] 索引警告
    private __item: ObservedPropertyObjectPU<LostItem>;
    get item() {
        return this.__item.get();
    }
    set item(newValue: LostItem) {
        this.__item.set(newValue);
    }
    private __comment: ObservedPropertySimplePU<string>;
    get comment() {
        return this.__comment.get();
    }
    set comment(newValue: string) {
        this.__comment.set(newValue);
    }
    private __comments: ObservedPropertyObjectPU<string[]>;
    get comments() {
        return this.__comments.get();
    }
    set comments(newValue: string[]) {
        this.__comments.set(newValue);
    }
    // 提交评论
    private async saveComment() {
        if (!this.comment.trim())
            return;
        this.comments.push(this.comment.trim());
        this.item.comments = this.comments;
        // 2. 写回总列表（注意：没有多写 .pref）
        const pref = await dataPreferences.getPreferences(this.context, 'lost');
        const raw = await pref.get('data', '[]') as string;
        const all: LostItem[] = JSON.parse(raw);
        const idx = all.findIndex(i => i.id === this.item.id);
        if (idx >= 0)
            all[idx] = this.item;
        await pref.put('data', JSON.stringify(all));
        await pref.flush(); // ✅ 正确写法
        this.comment = '';
        promptAction.showToast({ message: '评论已提交', duration: 1000 });
    }
    // 删除整条
    private async deleteItem() {
        const pref = await dataPreferences.getPreferences(this.context, 'lost');
        const raw = await pref.get('data', '[]') as string;
        let all: LostItem[] = JSON.parse(raw);
        all = all.filter(i => i.id !== this.item.id);
        await pref.put('data', JSON.stringify(all));
        await pref.flush();
        promptAction.showToast({ message: '已删除', duration: 1000 });
        router.back();
    }
    // 物理返回键
    onBackPress(): boolean {
        router.back();
        return true;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DetailPage.ets(63:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
            Column.padding(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部返回+标题
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/DetailPage.ets(65:7)", "entry");
            // 顶部返回+标题
            Row.width('100%');
            // 顶部返回+标题
            Row.padding(12);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 3. 临时用文本代替缺失的 back.png；有图后换成 Image($r('app.media.back'))
            Text.create('< 返回');
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(67:9)", "entry");
            // 3. 临时用文本代替缺失的 back.png；有图后换成 Image($r('app.media.back'))
            Text.fontSize(16);
            // 3. 临时用文本代替缺失的 back.png；有图后换成 Image($r('app.media.back'))
            Text.fontColor('#007DFF');
            // 3. 临时用文本代替缺失的 back.png；有图后换成 Image($r('app.media.back'))
            Text.onClick(() => router.back());
        }, Text);
        // 3. 临时用文本代替缺失的 back.png；有图后换成 Image($r('app.media.back'))
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('详情');
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(69:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ left: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/DetailPage.ets(70:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('删除');
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(71:9)", "entry");
            Text.fontColor('#FF4D4F');
            Text.onClick(() => this.deleteItem());
        }, Text);
        Text.pop();
        // 顶部返回+标题
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/DetailPage.ets(74:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.padding({ top: 12 });
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DetailPage.ets(75:9)", "entry");
            Column.padding(16);
            Column.width('100%');
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(12);
            Column.shadow({ radius: 4, color: '#20000000' });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.title);
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(76:11)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`时间：${this.item.time}`);
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(77:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`联系电话：${this.item.phone}`);
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(78:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('描述：');
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(79:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.desc);
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(80:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.detail) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('详细信息：');
                        Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(82:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#666');
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.item.detail);
                        Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(83:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#333');
                    }, Text);
                    Text.pop();
                });
            }
            // 评论列表
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 评论列表
            Text.create(`评论（${this.comments.length}）`);
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(87:11)", "entry");
            // 评论列表
            Text.fontSize(16);
            // 评论列表
            Text.fontWeight(FontWeight.Medium);
            // 评论列表
            Text.margin({ top: 20 });
        }, Text);
        // 评论列表
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.comments.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无评论');
                        Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(89:13)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#999');
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const c = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/DetailPage.ets(92:15)", "entry");
                                Row.margin({ top: 8 });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                // 4. Circle 用 .color() 而不是 .fillColor()
                                Circle.create();
                                Circle.debugLine("entry/src/main/ets/pages/DetailPage.ets(94:17)", "entry");
                                // 4. Circle 用 .color() 而不是 .fillColor()
                                Circle.width(8);
                                // 4. Circle 用 .color() 而不是 .fillColor()
                                Circle.height(8);
                                // 4. Circle 用 .color() 而不是 .fillColor()
                                Circle.fill('#007DFF');
                            }, Circle);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(c);
                                Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(98:17)", "entry");
                                Text.fontSize(14);
                                Text.fontColor('#333');
                                Text.margin({ left: 8 });
                            }, Text);
                            Text.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.comments, forEachItemGenFunction, (c: string) => c, false, false);
                    }, ForEach);
                    ForEach.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 写评论
            TextArea.create({ placeholder: '说点什么...', text: this.comment });
            TextArea.debugLine("entry/src/main/ets/pages/DetailPage.ets(104:11)", "entry");
            // 写评论
            TextArea.height(80);
            // 写评论
            TextArea.margin({ top: 16 });
            // 写评论
            TextArea.onChange(v => this.comment = v);
        }, TextArea);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('提交评论');
            Button.debugLine("entry/src/main/ets/pages/DetailPage.ets(107:11)", "entry");
            Button.width('100%');
            Button.margin({ top: 12 });
            Button.onClick(() => this.saveComment());
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DetailPage";
    }
}
registerNamedRoute(() => new DetailPage(undefined, {}), "", { bundleName: "com.example.lostfound", moduleName: "entry", pagePath: "pages/DetailPage", pageFullPath: "entry/src/main/ets/pages/DetailPage", integratedHsp: "false", moduleType: "followWithHap" });
